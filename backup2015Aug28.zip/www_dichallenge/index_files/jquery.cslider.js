<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /js/parallax-slider/jquery.cslider.js was not found on this server.</p>
<hr>
<address>Apache/2.2.15 (Scientific Linux) Server at hiroshima.mapping.jp Port 80</address>
</body></html>
